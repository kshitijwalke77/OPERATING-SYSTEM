#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXSIZE 27

int main() {
    int shmid;
    key_t key;
    char *shm, *s;

    key = 5679;

    shmid = shmget(key, MAXSIZE, 0666);
    if (shmid < 0) {
        printf("Error: shmget failed\n");
        exit(1);
    }

    shm = shmat(shmid, NULL, 0);
    if (shm == (char *) -1) {
        printf("Error: shmat failed\n");
        exit(1);
    }

    printf("\n\nClient started reading\n\n");

    for (s = shm; *s != '\0'; s++) {
        putchar(*s);
        printf("\t");
    }

    putchar('\n');

    *shm = '*';

    printf("\n\nClient Terminated!!!\n\n");

    return 0;
}

